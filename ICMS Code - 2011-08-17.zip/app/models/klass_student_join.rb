class KlassStudentJoin < ActiveRecord::Base
end
