class Ptbudget < ActiveRecord::Base
end
