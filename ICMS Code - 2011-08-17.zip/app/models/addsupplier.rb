class Addsupplier < ActiveRecord::Base
  belongs_to :supplier
end
