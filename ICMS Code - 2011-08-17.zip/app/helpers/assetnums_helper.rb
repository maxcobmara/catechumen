module AssetnumsHelper
end
