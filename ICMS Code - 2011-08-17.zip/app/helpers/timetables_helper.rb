module TimetablesHelper
end
