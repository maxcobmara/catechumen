module LoansHelper
end
