class Exammakerquestion < ActiveRecord::Base
  belongs_to :exammaker
end
