class Exammcqanswer < ActiveRecord::Base
  belongs_to :examquestion
end