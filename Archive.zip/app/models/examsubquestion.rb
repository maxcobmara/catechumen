class Examsubquestion < ActiveRecord::Base
  belongs_to :examquestion
end
